<?php
class Hello extends CI_Controller{

    function index(){
        echo "Panggil Aja Wildan Ganteng";
    }
    function show(){
        echo "I Make The World Better Place.";
    }

}